import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { webSocket, WebSocketSubject } from 'rxjs/webSocket';

const WEBSOCKET_URL = 'ws://localhost:8080/notifications';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

    private subject = webSocket('ws://localhost:8080/notifications');

  constructor() { }

  public connect(): Observable<any> {
    this.subject = webSocket(WEBSOCKET_URL);
    return this.subject;
  }

  public sendMessage(message: string) {
    this.subject.next(message);
  }

  public getNotifications(): Observable<any> {
    return this.subject.asObservable();
  }
}