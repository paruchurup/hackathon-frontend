import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-location-tracking',
  templateUrl: './location-tracking.component.html',
  styleUrls: ['./location-tracking.component.scss']
})
export class LocationTrackingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
